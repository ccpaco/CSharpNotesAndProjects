﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
	public static class Greedy
	{

		public static Change MakeChange(double dollarAmount)
		{
			int amount = (int)(100 * dollarAmount);
			int d = 0, q = 0, t = 0, n = 0, p = 0;
			d = amount / 100; amount -= 100 * d;
			q = amount / 25; amount -= 25 * q;
			t = amount / 10; amount -= 10 * t;
			n = amount / 5; amount -= 5 * n;
			p = amount;
			return new Change(d, q, t, n, p);
		}

		public struct Change
		{
			public Change(int d, int q, int t, int n, int p)
			{
				Dollars = d;
				Quarters = q;
				Dimes = t;
				Nickels = n;
				Pennies = p;
			}

			public int Dollars { get; private set; }
			public int Quarters { get; private set; }
			public int Dimes { get; private set; }
			public int Nickels { get; private set; }
			public int Pennies { get; private set; }

			public override string ToString()
			{
				StringBuilder s = new StringBuilder();
				void pluralizeAndAppend(int amount, string denom)
				{
					string ss = string.Empty;
					switch (amount)
					{
						case 0:	return;
						case 1:	ss = denom; break;
						default:	ss = denom + "s"; break;
					}
					if (s.Length > 0) s.Append(", ");
					s.Append($"{amount} {ss}");
				}
				pluralizeAndAppend(Dollars, "dollar");
				pluralizeAndAppend(Quarters, "quarter");
				pluralizeAndAppend(Dimes, "dime");
				pluralizeAndAppend(Nickels, "nickel");
				if (s.Length > 0) s.Append(", ");
				if (Pennies == 1) s.Append("1 penny"); else pluralizeAndAppend(Pennies, "pennie");
				return s.ToString();
			}
		}
	}
}
