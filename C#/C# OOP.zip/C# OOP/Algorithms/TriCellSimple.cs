﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{

	class TriCellSimple
	{
		public TriCellSimple Left { get; private set; }
		public TriCellSimple Right { get; private set; }
		public int Value { get; private set; }

		private int solution = -1;
		public int MaxPath()
		{
			if (solution >= 0) return solution;
			int left = (Left == null) ? 0 : Left.MaxPath(),
				right = (Right == null) ? 0 : Right.MaxPath();
			return solution = Value + Math.Max(left, right);
		}
	}

}
