﻿using ClassExamples.Chess;
using ClassExamples.Chess.Board;
using ClassExamples.Chess.Pieces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace ClassExamples.UnitTests.Chess
{
	[TestClass]
	public class ChessBoardTest
	{
		[TestMethod]
		public void SquareCount()
		{
			Assert.AreEqual(64, ChessBoard.SquareCount, "# squares on a chess board");
		}

		[TestMethod]
		public void EmptyBoard()
		{
			ChessBoard b = ChessBoard.EmptyBoard();
			Assert.AreEqual(0, b.PieceCount, "# pieces on empty board");
		}

		[TestMethod]
		public void NewGameBoard()
		{
			ChessBoard b = ChessBoard.NewGameBoard();
			Assert.AreEqual(32, b.PieceCount, "# pieces on new game board");
		}

		[TestMethod]
		public void PieceCount()
		{
			ChessBoard board = ChessBoard.EmptyBoard();
			Queen q = new Queen(Hue.Light);
			board.PlacePiece(Rank.Seven, File.D, q);
			Assert.AreEqual(1, board.PieceCount, "# pieces after adding queen");
			King k = new King(Hue.Light);
			board.PlacePiece(Rank.Six, File.G, k);
			Assert.AreEqual(2, board.PieceCount, "# pieces after adding queen & king");
		}

		[TestMethod]
		public void ChessSquareIndexer()
		{
			ChessBoard b = ChessBoard.EmptyBoard();
			Assert.IsFalse(b[Rank.One, File.A].IsOccupied);
			b.PlacePiece(Rank.One, File.A, new Bishop(Hue.Dark));
			Assert.IsTrue(b[Rank.One, File.A].IsOccupied);
		}

		[TestMethod]
		public void ChessSquareIndexerBaseline()
		{
			ChessBoard b = ChessBoard.EmptyBoard();
			foreach (Rank r in Enum.GetValues(typeof(Rank)))
			{
				foreach(File f in Enum.GetValues(typeof(File)))
				{
					Assert.IsFalse(b[r, f].IsOccupied, $"{r} {f}");
				}
			}
		}

		[TestMethod, ExpectedException(typeof(IllegalMoveException))]
		public void OccupySquareTwice()
		{
			ChessBoard b = ChessBoard.EmptyBoard();
			b.PlacePiece(Rank.Five, File.C, new Pawn(Hue.Light));
			// This is an illegal move:
			b.PlacePiece(Rank.Five, File.C, new Pawn(Hue.Light));
		}

		[TestMethod]
		public void SquaresTest()
		{
			PrivateObject po = new PrivateObject(typeof(ChessBoard));
			Assert.IsInstanceOfType(po.Target, typeof(ChessBoard));
			ChessSquare[] squares = po.GetField("_squares") as ChessSquare[];
			Assert.IsNotNull(squares);
			Assert.AreEqual(ChessBoard.SquareCount, squares.Length);
			CollectionAssert.AllItemsAreNotNull(squares, "all squares are instantiated");
		}

	}
}
