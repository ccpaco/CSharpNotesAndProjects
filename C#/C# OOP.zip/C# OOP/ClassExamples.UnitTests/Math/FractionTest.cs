﻿using System;
using ClassExamples.Math;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ClassExamples.UnitTests.Math
{
	[TestClass]
	public class FractionTest
	{
		private const double minDiff = 1e-10;
		private Fraction oneHalf, twoThirds, threeQuarters;

		[TestInitialize]
		public void InitTest()
		{
			oneHalf = new Fraction(1, 2);
			twoThirds = new Fraction(2, 3);
			threeQuarters = new Fraction(3, 4);
		}

		[TestMethod]
		public void NumeratorTest()
		{
			Assert.AreEqual(1, oneHalf.Numerator);
			Assert.AreEqual(2, twoThirds.Numerator);
			Assert.AreEqual(3, threeQuarters.Numerator);
		}

		[TestMethod]
		public void DenominatorTest()
		{
			Assert.AreEqual(2, oneHalf.Denominator);
			Assert.AreEqual(3, twoThirds.Denominator);
			Assert.AreEqual(4, threeQuarters.Denominator);
		}

		[TestMethod]
		public void RatioTest()
		{
			Assert.AreEqual(0.5, oneHalf.Ratio, minDiff);
			Assert.AreEqual(0.666666666667, twoThirds.Ratio, minDiff);
			Assert.AreEqual(0.75, threeQuarters.Ratio, minDiff);		
		}

		[TestMethod]
		public void NegationTest()
		{
			void testNeg(Fraction f)
			{
				Assert.AreEqual(-f.Numerator, f.Negation.Numerator);
				Assert.AreEqual(f.Denominator, f.Negation.Denominator);
			}
			testNeg(oneHalf);
			testNeg(twoThirds);
			testNeg(threeQuarters);
		}

		[TestMethod]
		public void ReciprocalTest()
		{
			void testRecip(Fraction f)
			{
				Fraction r = f.Reciprocal;
				Assert.AreEqual(f.Numerator, r.Denominator);
				Assert.AreEqual(f.Denominator, r.Numerator);
			}
			testRecip(oneHalf);
			testRecip(twoThirds);
			testRecip(threeQuarters);
		}

		[TestMethod]
		public void EqualsTest()
		{
			Assert.AreNotEqual(oneHalf, twoThirds);
			Assert.AreNotEqual(twoThirds, threeQuarters);
			Assert.AreNotEqual(threeQuarters, oneHalf);
			Assert.AreEqual(oneHalf, new Fraction(20, 40));
			Assert.AreEqual(twoThirds, new Fraction(6, 9));
			Assert.AreEqual(threeQuarters, new Fraction(36, 48));
		}

		[TestMethod]
		public void CopyConstructorTest()
		{
			void testCon(Fraction f)
			{
				Fraction f2 = new Fraction(f);
				Assert.AreEqual(f.Numerator, f2.Numerator);
				Assert.AreEqual(f.Denominator, f2.Denominator);
			}
			testCon(oneHalf);
			testCon(twoThirds);
			testCon(threeQuarters);
		}

		[TestMethod]
		public void ToStringTest()
		{
			Assert.AreEqual("1 / 2", oneHalf.ToString());
			Assert.AreEqual("2 / 3", twoThirds.ToString());
			Assert.AreEqual("3 / 4", threeQuarters.ToString());
		}

		[TestMethod]
		public void AdditionOperatorTest()
		{
			void testAdd(Fraction fA, Fraction fb, int num, int den)
			{
				Fraction sum = fA + fb;
				Assert.AreEqual(num, sum.Numerator);
				Assert.AreEqual(den, sum.Denominator);
			}
			testAdd(oneHalf, twoThirds, 7, 6);
			testAdd(twoThirds, threeQuarters, 17, 12);
			testAdd(threeQuarters, oneHalf, 5, 4);
		}

		[TestMethod]
		public void SubtractionOperatorTest()
		{
			void testSub(Fraction fA, Fraction fb, int num, int den)
			{
				Fraction sum = fA - fb;
				Assert.AreEqual(num, sum.Numerator);
				Assert.AreEqual(den, sum.Denominator);
			}
			testSub(oneHalf, twoThirds, -1, 6);
			testSub(twoThirds, threeQuarters, -1, 12);
			testSub(threeQuarters, oneHalf, 1, 4);
		}

		[TestMethod]
		public void MultiplicationOperatorTest()
		{
			void testMult(Fraction fA, Fraction fB)
			{
				Fraction product = fA * fB;
				Assert.AreEqual(fA.Numerator * fB.Numerator, product.Numerator);
				Assert.AreEqual(fA.Denominator * fB.Denominator, product.Denominator);
			}
			testMult(oneHalf, twoThirds);
			testMult(twoThirds, threeQuarters);
			testMult(threeQuarters, oneHalf);
		}

		[TestMethod]
		public void DivisionOperatorTest()
		{
			void testDiv(Fraction fA, Fraction fB)
			{
				Fraction res = fA / fB;
				Assert.AreEqual(fA.Numerator * fB.Denominator, res.Numerator);
				Assert.AreEqual(fA.Denominator * fB.Numerator, res.Denominator);
			}
			testDiv(oneHalf, twoThirds);
			testDiv(twoThirds, threeQuarters);
			testDiv(threeQuarters, oneHalf);
		}

		[TestMethod]
		public void EqualityOperatorTest()
		{
			Fraction f1 = null, f2 = null;
			Assert.IsTrue(f1 == f2);
			Assert.IsFalse(oneHalf == f1);
			Assert.IsFalse(oneHalf == twoThirds);
			Assert.IsFalse(twoThirds == threeQuarters);
			f1 = new Fraction(1000, 1500);
			Assert.IsTrue(twoThirds == f1);
		}

		[TestMethod]
		public void InequalityOperatorTest()
		{
			Fraction f1 = null, f2 = null;
			Assert.IsFalse(f1 != f2);
			Assert.IsTrue(oneHalf != f1);
			Assert.IsTrue(oneHalf != twoThirds);
			Assert.IsTrue(twoThirds != threeQuarters);
			f1 = new Fraction(1000, 1500);
			Assert.IsFalse(twoThirds != f1);

		}

		[TestMethod]
		public void CastToDoubleTest()
		{
			double d = oneHalf;
			Assert.AreEqual(0.5, d, minDiff);
			d = twoThirds;
			Assert.AreEqual(0.666666666667, d, minDiff);
			d = threeQuarters;
			Assert.AreEqual(0.75, d, minDiff);
			Fraction f = null;
			d = f;
			Assert.AreEqual(0, d, 0);
		}

		[TestMethod]
		public void FindLeastCommonMultipleTest()
		{
			PrivateType pt = new PrivateType(typeof(Fraction));
			int res = (int)pt.InvokeStatic("FindLeastCommonMultiple", 1, 1);
			Assert.AreEqual(1, res);
			res = (int)pt.InvokeStatic("FindLeastCommonMultiple", 10, 25);
			Assert.AreEqual(50, res);
			res = (int)pt.InvokeStatic("FindLeastCommonMultiple", 12, 17);
			Assert.AreEqual(12 * 17, res);
			res = (int)pt.InvokeStatic("FindLeastCommonMultiple", 17, 51);
			Assert.AreEqual(51, res);
		}
	}
}
