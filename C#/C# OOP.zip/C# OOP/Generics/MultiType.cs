﻿namespace Generics
{
	public class MultiType<T,U>
		where T : class, new()
		where U : struct
	{
		// define class members
	}
}
